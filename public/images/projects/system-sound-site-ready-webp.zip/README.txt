SYSTEM / SOUND - Site-ready WebP
================================

用途: ポートフォリオサイトのプロジェクトプレビュー画像

設定:
  02〜06: WebP quality=92（高品質）
  07〜10: WebP lossless（細かい文字優先）
  元画像のピクセル寸法は変更していません。
  No.1 Threads はSVGのまま使用してください。

ファイル一覧:
  02-image-processing-zip-tool.webp | 1448×1086 | quality=92 | PNG 2.06 MB -> WebP 0.24 MB
  03-product-selection-assist.webp | 1448×1086 | quality=92 | PNG 1.13 MB -> WebP 0.12 MB
  04-ai-voice-studio.webp | 1536×1024 | quality=92 | PNG 1.27 MB -> WebP 0.13 MB
  05-codex-novel-workflow.webp | 1448×1086 | quality=92 | PNG 1.66 MB -> WebP 0.21 MB
  06-line-stamp-sales-flow.webp | 1402×1122 | quality=92 | PNG 1.46 MB -> WebP 0.19 MB
  07-construction-spec-platform.webp | 1536×1024 | lossless | PNG 1.15 MB -> WebP 0.68 MB
  08-technical-doc-search-db.webp | 1536×1024 | lossless | PNG 1.34 MB -> WebP 0.81 MB
  09-rack-layout-designer.webp | 1536×1024 | lossless | PNG 1.29 MB -> WebP 0.79 MB
  10-maintenance-search-tool.webp | 1535×1024 | lossless | PNG 1.14 MB -> WebP 0.81 MB